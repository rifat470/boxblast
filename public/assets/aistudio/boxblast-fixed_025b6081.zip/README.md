# BoxBlast (Telegram Mini App)
Vercel: Framework Vite, Build `npm run build`, Output `dist`.
Optional env: VITE_ADSGRAM_BLOCK_ID, VITE_BOT_LINK, VITE_APP_LINK
