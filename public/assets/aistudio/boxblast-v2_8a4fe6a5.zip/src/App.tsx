import { useState, useEffect, useRef, useCallback } from 'react';

declare global {
  interface Window { Adsgram: any; Telegram: any; }
}

// Adsgram Partner panel থেকে বানানো REWARD ব্লকের numeric ID (.env এ VITE_ADSGRAM_BLOCK_ID)
const BLOCK_ID = (import.meta as any).env?.VITE_ADSGRAM_BLOCK_ID || '';
const MAX_ADS_PER_DAY = 6;
const GAME_SECONDS = 30;
// প্রতিটি ঘরের নিজস্ব পয়েন্ট (ঘর 0..8, বাঁ থেকে ডানে, উপর থেকে নিচে)
const CELL_POINTS = [1, 2, 3, 4, 5, 6, 7, 8, 9];

const today = () => new Date().toISOString().split('T')[0];
const yesterday = () => new Date(Date.now() - 86400000).toISOString().split('T')[0];
const ls = {
  num: (k: string) => Number(localStorage.getItem(k) || 0),
  set: (k: string, v: string | number) => localStorage.setItem(k, String(v)),
};
const haptic = (kind: 'light' | 'medium' = 'light') => {
  try { window.Telegram?.WebApp?.HapticFeedback?.impactOccurred(kind); } catch { /* ignore */ }
};

export default function App() {
  const [coins, setCoins] = useState(0);
  const [best, setBest] = useState(0);
  const [streak, setStreak] = useState(0);
  const [dailyDate, setDailyDate] = useState('');
  const [adsToday, setAdsToday] = useState(0);
  const [msg, setMsg] = useState('');
  const [busy, setBusy] = useState(false);

  const [playing, setPlaying] = useState(false);
  const [timeLeft, setTimeLeft] = useState(GAME_SECONDS);
  const [score, setScore] = useState(0);
  const [active, setActive] = useState(-1);
  const [boom, setBoom] = useState<{ cell: number; pts: number; id: number } | null>(null);
  const [lastScore, setLastScore] = useState(0);
  const [bonusDone, setBonusDone] = useState(true);

  const adRef = useRef<any>(null);
  const scoreRef = useRef(0);
  const hitsRef = useRef(0);
  const activeRef = useRef(-1);
  const spawnT = useRef<any>(null);
  const nextT = useRef<any>(null);
  const spawnFn = useRef<() => void>(() => {});

  const flash = (m: string, ms = 2500) => { setMsg(m); setTimeout(() => setMsg(''), ms); };
  const addCoins = useCallback((n: number) => {
    setCoins((c) => { const v = c + n; ls.set('bb_coins', v); return v; });
  }, []);

  useEffect(() => {
    if (localStorage.getItem('bb_ads_date') !== today()) { localStorage.setItem('bb_ads_date', today()); ls.set('bb_ads_n', 0); }
    setAdsToday(ls.num('bb_ads_n'));
    setCoins(ls.num('bb_coins'));
    setBest(ls.num('bb_best'));
    const last = localStorage.getItem('bb_daily_date') || '';
    setDailyDate(last);
    if (last && last !== today() && last !== yesterday()) { setStreak(0); ls.set('bb_streak', 0); }
    else setStreak(ls.num('bb_streak'));
    try {
      const tg = window.Telegram?.WebApp;
      if (tg?.initData) {
        tg.ready(); tg.expand();
        tg.disableVerticalSwipes?.(); // খেলার সময় সোয়াইপে অ্যাপ বন্ধ/মিনিমাইজ হবে না
      }
      if (window.Adsgram && BLOCK_ID) adRef.current = window.Adsgram.init({ blockId: BLOCK_ID });
    } catch { /* ignore */ }
  }, []);

  // বক্স একটি ঘরে দেখায়, না ফাটলে কিছুক্ষণ পর অন্য ঘরে যায় (কোনো পেনাল্টি নেই)
  spawnFn.current = () => {
    let cell = Math.floor(Math.random() * 9);
    if (cell === activeRef.current) cell = (cell + 1 + Math.floor(Math.random() * 8)) % 9;
    activeRef.current = cell;
    setActive(cell);
    const life = Math.max(600, 1100 - hitsRef.current * 12);
    clearTimeout(spawnT.current);
    spawnT.current = setTimeout(() => {
      activeRef.current = -1; setActive(-1);
      nextT.current = setTimeout(() => spawnFn.current(), 120);
    }, life);
  };

  useEffect(() => {
    if (!playing) return;
    const endAt = Date.now() + GAME_SECONDS * 1000;
    const tick = setInterval(() => {
      const left = Math.max(0, Math.ceil((endAt - Date.now()) / 1000));
      setTimeLeft(left);
      if (left <= 0) finishGame();
    }, 200);
    spawnFn.current();
    return () => { clearInterval(tick); clearTimeout(spawnT.current); clearTimeout(nextT.current); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [playing]);

  const startGame = () => {
    scoreRef.current = 0; hitsRef.current = 0; activeRef.current = -1;
    setScore(0); setTimeLeft(GAME_SECONDS); setBoom(null); setBonusDone(true);
    setPlaying(true);
  };
  const finishGame = () => {
    clearTimeout(spawnT.current); clearTimeout(nextT.current);
    activeRef.current = -1; setActive(-1); setPlaying(false);
    const s = scoreRef.current;
    setLastScore(s);
    addCoins(s);
    if (s > ls.num('bb_best')) { ls.set('bb_best', s); setBest(s); }
    setBonusDone(s === 0);
    haptic('medium');
  };

  // ইউজার যে ঘরে ট্যাপ করবে, বক্স সেই ঘরে থাকলে সেখানেই ফাটবে
  const tapCell = (i: number) => {
    if (!playing || i !== activeRef.current) return;
    activeRef.current = -1; // একই বক্স দুইবার গোনা হবে না
    clearTimeout(spawnT.current);
    const pts = CELL_POINTS[i];
    scoreRef.current += pts; hitsRef.current += 1;
    setScore(scoreRef.current);
    setActive(-1);
    setBoom({ cell: i, pts, id: Date.now() });
    haptic('light');
    clearTimeout(nextT.current);
    nextT.current = setTimeout(() => spawnFn.current(), 140);
  };

  // রিওয়ার্ড বিজ্ঞাপন: সম্পূর্ণ না দেখলে কোনো কয়েন নয়
  const showRewardedAd = async (): Promise<boolean> => {
    if (adsToday >= MAX_ADS_PER_DAY) { flash('আজকের বিজ্ঞাপন সীমা শেষ। কাল আবার চেষ্টা করুন।'); return false; }
    if (!window.Telegram?.WebApp?.initData || !adRef.current) { flash('বিজ্ঞাপন দেখতে অ্যাপটি Telegram এর ভেতরে খুলুন।'); return false; }
    setBusy(true);
    try {
      await adRef.current.show(); // resolve = শেষ পর্যন্ত দেখেছে
      const n = adsToday + 1; setAdsToday(n); ls.set('bb_ads_n', n);
      return true;
    } catch (e: any) {
      flash(/no.?ad/i.test(String(e?.description)) ? 'এখন কোনো বিজ্ঞাপন নেই, পরে চেষ্টা করুন।' : 'বিজ্ঞাপন শেষ পর্যন্ত দেখা হয়নি, তাই বোনাস নেই।');
      return false;
    } finally { setBusy(false); }
  };

  const claimDouble = async () => {
    if (await showRewardedAd()) { addCoins(lastScore); setBonusDone(true); flash(`✅ বোনাস +${lastScore}`); }
  };
  const dailyClaimed = dailyDate === today();
  const claimDaily = async () => {
    if (dailyClaimed) return;
    if (await showRewardedAd()) {
      const ns = (dailyDate === yesterday() ? streak : 0) + 1;
      setStreak(ns); ls.set('bb_streak', ns);
      setDailyDate(today()); localStorage.setItem('bb_daily_date', today());
      addCoins(50); flash('✅ ডেইলি বোনাস +50');
    }
  };

  const card: React.CSSProperties = { background: '#1c1c2e', borderRadius: 16, padding: 14, marginTop: 12 };
  const btn = (disabled: boolean, primary = true): React.CSSProperties => ({
    width: '100%', padding: 12, borderRadius: 10, border: 0, fontWeight: 'bold', fontSize: 14,
    background: disabled ? '#333' : primary ? '#6c5cff' : '#fff', color: disabled ? '#777' : primary ? '#fff' : '#000',
    cursor: disabled ? 'not-allowed' : 'pointer', touchAction: 'manipulation',
  });

  return (
    <div style={{ background: '#0e0e1a', color: '#fff', fontFamily: 'system-ui,sans-serif', minHeight: '100vh', userSelect: 'none', WebkitUserSelect: 'none', WebkitTapHighlightColor: 'transparent' }}>
      <style>{`
        @keyframes bbPop { 0%{transform:scale(.4);opacity:1} 60%{transform:scale(1.5);opacity:1} 100%{transform:scale(1.9);opacity:0} }
        @keyframes bbRise { 0%{transform:translateY(0);opacity:1} 100%{transform:translateY(-34px);opacity:0} }
        @keyframes bbIn { 0%{transform:scale(.5)} 100%{transform:scale(1)} }
      `}</style>
      <div style={{ padding: '14px 16px', background: '#1c1c2e', display: 'flex', justifyContent: 'space-between', position: 'sticky', top: 0, zIndex: 5 }}>
        <b>📦 BoxBlast</b>
        <span style={{ background: '#6c5cff', padding: '5px 14px', borderRadius: 20, fontWeight: 'bold' }}>⭐ {coins}</span>
      </div>
      {msg && <div style={{ margin: '8px 14px', padding: 10, borderRadius: 10, textAlign: 'center', background: '#6c5cff' }}>{msg}</div>}

      <div style={{ padding: '4px 14px 30px' }}>
        <div style={card}>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 14 }}>
            <span>🎯 Score: <b>{score}</b></span>
            <span>⏱ {timeLeft}s</span>
            <span>🏆 Best: <b>{best}</b></span>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 10, margin: '14px 0' }}>
            {CELL_POINTS.map((pts, i) => (
              <div key={i} onPointerDown={(e) => { e.preventDefault(); tapCell(i); }}
                style={{ position: 'relative', aspectRatio: '1', borderRadius: 14, border: '1px solid #2a2a4a', touchAction: 'none',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 34,
                  background: playing && active === i ? '#6c5cff' : '#12121a', overflow: 'visible' }}>
                <span style={{ position: 'absolute', top: 5, left: 8, fontSize: 11, color: '#7a7aa8', fontWeight: 'bold' }}>+{pts}</span>
                {playing && active === i && <span style={{ animation: 'bbIn .12s ease-out' }}>📦</span>}
                {boom && boom.cell === i && (
                  <>
                    <span key={'b' + boom.id} style={{ position: 'absolute', fontSize: 40, animation: 'bbPop .35s ease-out forwards', pointerEvents: 'none' }}>💥</span>
                    <span key={'p' + boom.id} style={{ position: 'absolute', fontSize: 18, fontWeight: 'bold', color: '#ffd84d', animation: 'bbRise .6s ease-out forwards', pointerEvents: 'none' }}>+{boom.pts}</span>
                  </>
                )}
              </div>
            ))}
          </div>
          <button onClick={startGame} disabled={playing} style={btn(playing)}>
            {playing ? 'বক্সে ট্যাপ করুন!' : lastScore || score ? '▶️ আবার খেলুন' : '▶️ খেলা শুরু করুন'}
          </button>
          <p style={{ fontSize: 11, color: '#aaa', textAlign: 'center', margin: '8px 0 0' }}>
            {GAME_SECONDS} সেকেন্ডে বক্স যে ঘরে আসে সেখানে ট্যাপ করে ফাটান। প্রতিটি ঘরের পয়েন্ট আলাদা (১–৯), পয়েন্ট = কয়েন। বিজ্ঞাপন সম্পূর্ণ ঐচ্ছিক।
          </p>
        </div>

        {!playing && !bonusDone && lastScore > 0 && (
          <div style={card}>
            <div style={{ marginBottom: 8 }}>🎉 আপনি পেয়েছেন {lastScore} কয়েন। চাইলে বিজ্ঞাপন দেখে আরও +{lastScore} নিন (ঐচ্ছিক)।</div>
            <button onClick={claimDouble} disabled={busy} style={btn(busy, false)}>{busy ? '⏳ লোড হচ্ছে...' : `▶️ বিজ্ঞাপন দেখে +${lastScore}`}</button>
          </div>
        )}

        <div style={{ ...card, background: 'linear-gradient(135deg,#6c5cff,#00d2ff)', textAlign: 'center' }}>
          <div style={{ fontWeight: 'bold', fontSize: 17 }}>🔥 Daily Streak: {streak} দিন</div>
          <button onClick={claimDaily} disabled={dailyClaimed || busy || playing} style={{ ...btn(dailyClaimed || busy || playing, false), marginTop: 10 }}>
            {dailyClaimed ? '✅ আজকের বোনাস নেওয়া হয়েছে' : '▶️ ডেইলি বোনাস +50 (ঐচ্ছিক বিজ্ঞাপন)'}
          </button>
        </div>

        <p style={{ fontSize: 11, color: '#777', textAlign: 'center', marginTop: 16, lineHeight: 1.5 }}>
          কয়েন শুধুমাত্র অ্যাপের ভেতরের স্কোরের জন্য; এর কোনো নগদ মূল্য নেই এবং তোলা যায় না।
        </p>
      </div>
    </div>
  );
}
