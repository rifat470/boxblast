import { useState, useEffect, useRef, useCallback } from 'react';

declare global {
  interface Window { Adsgram: any; Telegram: any; }
}

// Adsgram Partner panel থেকে বানানো REWARD ব্লকের numeric ID (.env এ VITE_ADSGRAM_BLOCK_ID)
const BLOCK_ID = (import.meta as any).env?.VITE_ADSGRAM_BLOCK_ID || '';
const MAX_ADS_PER_DAY = 6;
const GAME_SECONDS = 30;

const today = () => new Date().toISOString().split('T')[0];
const yesterday = () => new Date(Date.now() - 86400000).toISOString().split('T')[0];
const ls = {
  num: (k: string) => Number(localStorage.getItem(k) || 0),
  set: (k: string, v: string | number) => localStorage.setItem(k, String(v)),
};

export default function App() {
  const [coins, setCoins] = useState(0);
  const [best, setBest] = useState(0);
  const [streak, setStreak] = useState(0);
  const [dailyDate, setDailyDate] = useState('');
  const [adsToday, setAdsToday] = useState(0);
  const [msg, setMsg] = useState('');
  const [busy, setBusy] = useState(false);

  const [playing, setPlaying] = useState(false);
  const [timeLeft, setTimeLeft] = useState(GAME_SECONDS);
  const [score, setScore] = useState(0);
  const [active, setActive] = useState(-1);
  const [lastScore, setLastScore] = useState(0);
  const [doubled, setDoubled] = useState(true); // true = এই রাউন্ডের বোনাস নেওয়া/অপ্রযোজ্য

  const adRef = useRef<any>(null);
  const scoreRef = useRef(0);

  const flash = (m: string, ms = 2500) => { setMsg(m); setTimeout(() => setMsg(''), ms); };
  const addCoins = useCallback((n: number) => {
    setCoins((c) => { const v = c + n; ls.set('bb_coins', v); return v; });
  }, []);

  useEffect(() => {
    if (ls.num('bb_ads_date_n') !== 0 && localStorage.getItem('bb_ads_date') !== today()) ls.set('bb_ads_n', 0);
    if (localStorage.getItem('bb_ads_date') !== today()) { localStorage.setItem('bb_ads_date', today()); ls.set('bb_ads_n', 0); }
    setAdsToday(ls.num('bb_ads_n'));
    setCoins(ls.num('bb_coins'));
    setBest(ls.num('bb_best'));
    setStreak(ls.num('bb_streak'));
    setDailyDate(localStorage.getItem('bb_daily_date') || '');
    // streak ছিঁড়ে গেলে রিসেট
    const last = localStorage.getItem('bb_daily_date') || '';
    if (last && last !== today() && last !== yesterday()) { setStreak(0); ls.set('bb_streak', 0); }
    try {
      const tg = window.Telegram?.WebApp;
      if (tg?.initData) { tg.ready(); tg.expand(); }
      if (window.Adsgram && BLOCK_ID) adRef.current = window.Adsgram.init({ blockId: BLOCK_ID });
    } catch { /* ignore */ }
  }, []);

  // Game timer + box movement
  useEffect(() => {
    if (!playing) return;
    const t = setInterval(() => {
      setTimeLeft((s) => {
        if (s <= 1) { clearInterval(t); endGame(); return 0; }
        return s - 1;
      });
    }, 1000);
    const m = setInterval(() => setActive(Math.floor(Math.random() * 9)), 700);
    setActive(Math.floor(Math.random() * 9));
    return () => { clearInterval(t); clearInterval(m); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [playing]);

  const startGame = () => {
    scoreRef.current = 0; setScore(0); setTimeLeft(GAME_SECONDS);
    setDoubled(true); setPlaying(true);
  };
  const endGame = () => {
    setPlaying(false); setActive(-1);
    const s = scoreRef.current;
    setLastScore(s);
    addCoins(s);
    if (s > ls.num('bb_best')) { ls.set('bb_best', s); setBest(s); }
    setDoubled(s === 0); // স্কোর থাকলে ঐচ্ছিক ×2 বোনাস দেখাবে
  };
  const tapBox = (i: number) => {
    if (!playing || i !== active) return;
    scoreRef.current += 1; setScore(scoreRef.current);
    setActive(Math.floor(Math.random() * 9));
  };

  // রিওয়ার্ড বিজ্ঞাপন: সম্পূর্ণ না দেখলে কোনো কয়েন নয়
  const showRewardedAd = async (): Promise<boolean> => {
    if (adsToday >= MAX_ADS_PER_DAY) { flash('আজকের বিজ্ঞাপন সীমা শেষ। কাল আবার চেষ্টা করুন।'); return false; }
    if (!adRef.current) { flash('বিজ্ঞাপন এখন পাওয়া যাচ্ছে না (Telegram এর ভেতরে খুলুন)।'); return false; }
    setBusy(true);
    try {
      await adRef.current.show(); // resolve = শেষ পর্যন্ত দেখেছে
      const n = adsToday + 1; setAdsToday(n); ls.set('bb_ads_n', n);
      return true;
    } catch (e: any) {
      flash(e?.description === 'no ads' || /no.?ad/i.test(String(e?.description)) ? 'এখন কোনো বিজ্ঞাপন নেই, পরে চেষ্টা করুন।' : 'বিজ্ঞাপন শেষ পর্যন্ত দেখা হয়নি, তাই বোনাস নেই।');
      return false;
    } finally { setBusy(false); }
  };

  const claimDouble = async () => {
    if (await showRewardedAd()) { addCoins(lastScore); setDoubled(true); flash(`✅ বোনাস +${lastScore}`); }
  };
  const dailyClaimed = dailyDate === today();
  const claimDaily = async () => {
    if (dailyClaimed) return;
    if (await showRewardedAd()) {
      const ns = (dailyDate === yesterday() ? streak : 0) + 1;
      setStreak(ns); ls.set('bb_streak', ns);
      setDailyDate(today()); localStorage.setItem('bb_daily_date', today());
      addCoins(50); flash('✅ ডেইলি বোনাস +50');
    }
  };

  const card: React.CSSProperties = { background: '#1c1c2e', borderRadius: 16, padding: 14, marginTop: 12 };
  const btn = (disabled: boolean, primary = true): React.CSSProperties => ({
    width: '100%', padding: 12, borderRadius: 10, border: 0, fontWeight: 'bold', fontSize: 14,
    background: disabled ? '#333' : primary ? '#6c5cff' : '#fff', color: disabled ? '#777' : primary ? '#fff' : '#000',
    cursor: disabled ? 'not-allowed' : 'pointer',
  });

  return (
    <div style={{ background: '#0e0e1a', color: '#fff', fontFamily: 'system-ui,sans-serif', minHeight: '100vh' }}>
      <div style={{ padding: '14px 16px', background: '#1c1c2e', display: 'flex', justifyContent: 'space-between', position: 'sticky', top: 0, zIndex: 5 }}>
        <b>📦 BoxBlast</b>
        <span style={{ background: '#6c5cff', padding: '5px 14px', borderRadius: 20, fontWeight: 'bold' }}>⭐ {coins}</span>
      </div>
      {msg && <div style={{ margin: '8px 14px', padding: 10, borderRadius: 10, textAlign: 'center', background: '#6c5cff' }}>{msg}</div>}

      <div style={{ padding: '4px 14px 30px' }}>
        <div style={card}>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 14 }}>
            <span>🎯 Score: <b>{score}</b></span>
            <span>⏱ {timeLeft}s</span>
            <span>🏆 Best: <b>{best}</b></span>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 10, margin: '14px 0' }}>
            {Array.from({ length: 9 }).map((_, i) => (
              <button key={i} onPointerDown={() => tapBox(i)}
                style={{ aspectRatio: '1', borderRadius: 14, border: '1px solid #2a2a4a', fontSize: 30,
                  background: playing && active === i ? '#6c5cff' : '#12121a', transition: 'background .1s' }}>
                {playing && active === i ? '📦' : ''}
              </button>
            ))}
          </div>
          <button onClick={startGame} disabled={playing} style={btn(playing)}>
            {playing ? 'বক্সে ট্যাপ করুন!' : lastScore || score ? '▶️ আবার খেলুন' : '▶️ খেলা শুরু করুন'}
          </button>
          <p style={{ fontSize: 11, color: '#aaa', textAlign: 'center', margin: '8px 0 0' }}>
            {GAME_SECONDS} সেকেন্ডে যত বেশি বক্স ফাটাবেন তত কয়েন (১ বক্স = ১ কয়েন)। বিজ্ঞাপন সম্পূর্ণ ঐচ্ছিক।
          </p>
        </div>

        {!playing && !doubled && lastScore > 0 && (
          <div style={card}>
            <div style={{ marginBottom: 8 }}>🎉 আপনি পেয়েছেন {lastScore} কয়েন। চাইলে বিজ্ঞাপন দেখে আরও +{lastScore} নিন (ঐচ্ছিক)।</div>
            <button onClick={claimDouble} disabled={busy} style={btn(busy, false)}>{busy ? '⏳ লোড হচ্ছে...' : `▶️ বিজ্ঞাপন দেখে +${lastScore}`}</button>
          </div>
        )}

        <div style={{ ...card, background: 'linear-gradient(135deg,#6c5cff,#00d2ff)', textAlign: 'center' }}>
          <div style={{ fontWeight: 'bold', fontSize: 17 }}>🔥 Daily Streak: {streak} দিন</div>
          <button onClick={claimDaily} disabled={dailyClaimed || busy || playing} style={{ ...btn(dailyClaimed || busy || playing, false), marginTop: 10 }}>
            {dailyClaimed ? '✅ আজকের বোনাস নেওয়া হয়েছে' : '▶️ ডেইলি বোনাস +50 (ঐচ্ছিক বিজ্ঞাপন)'}
          </button>
        </div>

        <p style={{ fontSize: 11, color: '#777', textAlign: 'center', marginTop: 16, lineHeight: 1.5 }}>
          কয়েন শুধুমাত্র অ্যাপের ভেতরের স্কোরের জন্য; এর কোনো নগদ মূল্য নেই এবং তোলা যায় না।
        </p>
      </div>
    </div>
  );
}
