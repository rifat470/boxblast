import { useState, useEffect, useRef, useCallback, type CSSProperties } from 'react';

declare global {
  interface Window { Adsgram: any; Telegram: any; }
}

// Adsgram Partner panel থেকে বানানো REWARD ব্লকের numeric ID (.env এ VITE_ADSGRAM_BLOCK_ID)
const BLOCK_ID = (import.meta as any).env?.VITE_ADSGRAM_BLOCK_ID || '';
const MAX_ADS_PER_DAY = 8;
const EXTRA_SECONDS = 10;
const GAME_SECONDS = 30;
// প্রতিবার বক্স আসার সময় ১..MAX_POINTS এর মধ্যে র‍্যান্ডম পয়েন্ট (আগে থেকে দেখা বা আন্দাজ করা যায় না)
const MAX_POINTS = 9;
const GOLD_POINTS = 15; // 🌟 গোল্ডেন বক্স
const BOMB_PENALTY = 10; // 💣 বোমা বক্স

const today = () => new Date().toISOString().split('T')[0];
const yesterday = () => new Date(Date.now() - 86400000).toISOString().split('T')[0];
const ls = {
  num: (k: string) => Number(localStorage.getItem(k) || 0),
  set: (k: string, v: string | number) => localStorage.setItem(k, String(v)),
};
const haptic = (kind: 'light' | 'medium' = 'light') => {
  try { window.Telegram?.WebApp?.HapticFeedback?.impactOccurred(kind); } catch { /* ignore */ }
};

export default function App() {
  const [coins, setCoins] = useState(0);
  const [best, setBest] = useState(0);
  const [streak, setStreak] = useState(0);
  const [dailyDate, setDailyDate] = useState('');
  const [adsToday, setAdsToday] = useState(0);
  const [msg, setMsg] = useState('');
  const [busy, setBusy] = useState(false);

  const [playing, setPlaying] = useState(false);
  const [timeLeft, setTimeLeft] = useState(GAME_SECONDS);
  const [score, setScore] = useState(0);
  const [active, setActive] = useState(-1);
  const [boom, setBoom] = useState<{ cell: number; pts: number; id: number } | null>(null);
  const [lastScore, setLastScore] = useState(0);
  const [bonusDone, setBonusDone] = useState(true);

  const adRef = useRef<any>(null);
  const scoreRef = useRef(0);
  const hitsRef = useRef(0);
  const activeRef = useRef(-1);
  const pointsRef = useRef(1);
  const typeRef = useRef<'n' | 'g' | 'b'>('n');
  const comboRef = useRef(0);
  const durRef = useRef(GAME_SECONDS);
  const extraUsed = useRef(false);
  const mRef = useRef({ blast: 0, c1: false, c2: false });
  const [activeType, setActiveType] = useState<'n' | 'g' | 'b'>('n');
  const [combo, setCombo] = useState(0);
  const [xp, setXp] = useState(0);
  const [m, setM] = useState({ blast: 0, c1: false, c2: false });
  const [canExtra, setCanExtra] = useState(false);
  const spawnT = useRef<any>(null);
  const nextT = useRef<any>(null);
  const spawnFn = useRef<() => void>(() => {});

  const flash = (m: string, ms = 2500) => { setMsg(m); setTimeout(() => setMsg(''), ms); };
  const addCoins = useCallback((n: number) => {
    setCoins((c) => { const v = c + n; ls.set('bb_coins', v); return v; });
  }, []);

  const creditGame = (n: number) => {
    addCoins(n);
    setXp((x) => { const v = Math.max(0, x + n); ls.set('bb_xp', v); return v; });
  };
  const saveM = (next: { blast: number; c1: boolean; c2: boolean }) => {
    mRef.current = next; setM(next);
    localStorage.setItem('bb_m', JSON.stringify({ d: today(), ...next }));
  };

  useEffect(() => {
    if (localStorage.getItem('bb_ads_date') !== today()) { localStorage.setItem('bb_ads_date', today()); ls.set('bb_ads_n', 0); }
    setAdsToday(ls.num('bb_ads_n'));
    setCoins(ls.num('bb_coins'));
    setXp(ls.num('bb_xp'));
    try {
      const sm = JSON.parse(localStorage.getItem('bb_m') || '{}');
      const cur = sm.d === today() ? { blast: sm.blast || 0, c1: !!sm.c1, c2: !!sm.c2 } : { blast: 0, c1: false, c2: false };
      mRef.current = cur; setM(cur);
    } catch { /* ignore */ }
    setBest(ls.num('bb_best'));
    const last = localStorage.getItem('bb_daily_date') || '';
    setDailyDate(last);
    if (last && last !== today() && last !== yesterday()) { setStreak(0); ls.set('bb_streak', 0); }
    else setStreak(ls.num('bb_streak'));
    try {
      const tg = window.Telegram?.WebApp;
      if (tg?.initData) {
        tg.ready(); tg.expand();
        tg.disableVerticalSwipes?.(); // খেলার সময় সোয়াইপে অ্যাপ বন্ধ/মিনিমাইজ হবে না
      }
      if (window.Adsgram && BLOCK_ID) adRef.current = window.Adsgram.init({ blockId: BLOCK_ID });
    } catch { /* ignore */ }
  }, []);

  // বক্স একটি ঘরে দেখায়, না ফাটলে কিছুক্ষণ পর অন্য ঘরে যায় (কোনো পেনাল্টি নেই)
  spawnFn.current = () => {
    let cell = Math.floor(Math.random() * 9);
    if (cell === activeRef.current) cell = (cell + 1 + Math.floor(Math.random() * 8)) % 9;
    activeRef.current = cell;
    const r = Math.random();
    typeRef.current = r < 0.08 ? 'b' : r < 0.2 ? 'g' : 'n';
    pointsRef.current = typeRef.current === 'g' ? GOLD_POINTS : 1 + Math.floor(Math.random() * MAX_POINTS);
    setActiveType(typeRef.current);
    setActive(cell);
    const life = Math.max(600, 1100 - hitsRef.current * 12);
    clearTimeout(spawnT.current);
    spawnT.current = setTimeout(() => {
      if (typeRef.current !== 'b') { comboRef.current = 0; setCombo(0); } // বক্স মিস = কম্বো শেষ
      activeRef.current = -1; setActive(-1);
      nextT.current = setTimeout(() => spawnFn.current(), 120);
    }, life);
  };

  useEffect(() => {
    if (!playing) return;
    const endAt = Date.now() + durRef.current * 1000;
    const tick = setInterval(() => {
      const left = Math.max(0, Math.ceil((endAt - Date.now()) / 1000));
      setTimeLeft(left);
      if (left <= 0) finishGame();
    }, 200);
    spawnFn.current();
    return () => { clearInterval(tick); clearTimeout(spawnT.current); clearTimeout(nextT.current); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [playing]);

  const startGame = () => {
    scoreRef.current = 0; hitsRef.current = 0; activeRef.current = -1; comboRef.current = 0;
    durRef.current = GAME_SECONDS; extraUsed.current = false; setCanExtra(false);
    setScore(0); setCombo(0); setTimeLeft(GAME_SECONDS); setBoom(null); setBonusDone(true);
    setPlaying(true);
  };
  const finishGame = () => {
    clearTimeout(spawnT.current); clearTimeout(nextT.current);
    activeRef.current = -1; setActive(-1); setPlaying(false);
    const s = scoreRef.current;
    setLastScore(s);
    creditGame(s);
    if (s >= 100 && !mRef.current.c2) { saveM({ ...mRef.current, c2: true }); addCoins(30); flash('🎯 মিশন সম্পূর্ণ! +30'); }
    setCanExtra(!extraUsed.current && s > 0);
    if (s > ls.num('bb_best')) { ls.set('bb_best', s); setBest(s); }
    setBonusDone(s === 0);
    haptic('medium');
  };

  // ইউজার যে ঘরে ট্যাপ করবে, বক্স সেই ঘরে থাকলে সেখানেই ফাটবে
  const tapCell = (i: number) => {
    if (!playing || i !== activeRef.current) return;
    activeRef.current = -1; // একই বক্স দুইবার গোনা হবে না
    clearTimeout(spawnT.current);
    let pts: number;
    if (typeRef.current === 'b') {
      pts = -Math.min(BOMB_PENALTY, scoreRef.current);
      comboRef.current = 0; setCombo(0);
      haptic('medium');
    } else {
      comboRef.current += 1; setCombo(comboRef.current);
      const mult = 1 + Math.min(3, Math.floor(comboRef.current / 5)); // x1..x4
      pts = pointsRef.current * mult;
      hitsRef.current += 1;
      haptic('light');
      const nm = { ...mRef.current, blast: mRef.current.blast + 1 };
      if (nm.blast >= 50 && !nm.c1) { nm.c1 = true; addCoins(30); flash('🎯 মিশন সম্পূর্ণ! +30'); }
      saveM(nm);
    }
    scoreRef.current += pts;
    setScore(scoreRef.current);
    setActive(-1);
    setBoom({ cell: i, pts, id: Date.now() });
    clearTimeout(nextT.current);
    nextT.current = setTimeout(() => spawnFn.current(), 140);
  };

  // রিওয়ার্ড বিজ্ঞাপন: সম্পূর্ণ না দেখলে কোনো কয়েন নয়
  const showRewardedAd = async (): Promise<boolean> => {
    if (adsToday >= MAX_ADS_PER_DAY) { flash('আজকের বিজ্ঞাপন সীমা শেষ। কাল আবার চেষ্টা করুন।'); return false; }
    if (!window.Telegram?.WebApp?.initData || !adRef.current) { flash('বিজ্ঞাপন দেখতে অ্যাপটি Telegram এর ভেতরে খুলুন।'); return false; }
    setBusy(true);
    try {
      await adRef.current.show(); // resolve = শেষ পর্যন্ত দেখেছে
      const n = adsToday + 1; setAdsToday(n); ls.set('bb_ads_n', n);
      return true;
    } catch (e: any) {
      flash(/no.?ad/i.test(String(e?.description)) ? 'এখন কোনো বিজ্ঞাপন নেই, পরে চেষ্টা করুন।' : 'বিজ্ঞাপন শেষ পর্যন্ত দেখা হয়নি, তাই বোনাস নেই।');
      return false;
    } finally { setBusy(false); }
  };

  const claimDouble = async () => {
    if (await showRewardedAd()) { addCoins(lastScore); setBonusDone(true); flash(`✅ বোনাস +${lastScore}`); }
  };
  const claimExtra = async () => {
    if (extraUsed.current) return;
    if (await showRewardedAd()) {
      extraUsed.current = true; setCanExtra(false); setBonusDone(true);
      creditGame(-scoreRef.current); // শেষে আবার পুরো স্কোর যোগ হবে
      durRef.current = EXTRA_SECONDS; setTimeLeft(EXTRA_SECONDS); setPlaying(true);
    }
  };
  const dailyClaimed = dailyDate === today();
  const claimDaily = async () => {
    if (dailyClaimed) return;
    if (await showRewardedAd()) {
      const ns = (dailyDate === yesterday() ? streak : 0) + 1;
      setStreak(ns); ls.set('bb_streak', ns);
      setDailyDate(today()); localStorage.setItem('bb_daily_date', today());
      addCoins(50); flash('✅ ডেইলি বোনাস +50');
    }
  };

  const card: CSSProperties = { background: '#1c1c2e', borderRadius: 16, padding: 14, marginTop: 12 };
  const btn = (disabled: boolean, primary = true): CSSProperties => ({
    width: '100%', padding: 12, borderRadius: 10, border: 0, fontWeight: 'bold', fontSize: 14,
    background: disabled ? '#333' : primary ? '#6c5cff' : '#fff', color: disabled ? '#777' : primary ? '#fff' : '#000',
    cursor: disabled ? 'not-allowed' : 'pointer', touchAction: 'manipulation',
  });

  return (
    <div style={{ background: '#0e0e1a', color: '#fff', fontFamily: 'system-ui,sans-serif', minHeight: '100vh', userSelect: 'none', WebkitUserSelect: 'none', WebkitTapHighlightColor: 'transparent' }}>
      <style>{`
        @keyframes bbPop { 0%{transform:scale(.4);opacity:1} 60%{transform:scale(1.5);opacity:1} 100%{transform:scale(1.9);opacity:0} }
        @keyframes bbRise { 0%{transform:translateY(0);opacity:1} 100%{transform:translateY(-34px);opacity:0} }
        @keyframes bbIn { 0%{transform:scale(.5)} 100%{transform:scale(1)} }
      `}</style>
      <div style={{ padding: '14px 16px', background: '#1c1c2e', display: 'flex', justifyContent: 'space-between', position: 'sticky', top: 0, zIndex: 5 }}>
        <b>📦 BoxBlast <span style={{ fontSize: 12, color: '#9a9ad0', marginLeft: 6 }}>Lv {1 + Math.floor(xp / 300)}</span></b>
        <span style={{ background: '#6c5cff', padding: '5px 14px', borderRadius: 20, fontWeight: 'bold' }}>⭐ {coins}</span>
      </div>
      {msg && <div style={{ margin: '8px 14px', padding: 10, borderRadius: 10, textAlign: 'center', background: '#6c5cff' }}>{msg}</div>}

      <div style={{ padding: '4px 14px 30px' }}>
        <div style={card}>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 14 }}>
            <span>🎯 Score: <b>{score}</b>{combo >= 5 ? <b style={{ color: '#ffd84d' }}> 🔥x{1 + Math.min(3, Math.floor(combo / 5))}</b> : null}</span>
            <span>⏱ {timeLeft}s</span>
            <span>🏆 Best: <b>{best}</b></span>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 10, margin: '14px 0' }}>
            {Array.from({ length: 9 }, (_, i) => i).map((i) => (
              <div key={i} onPointerDown={(e) => { e.preventDefault(); tapCell(i); }}
                style={{ position: 'relative', aspectRatio: '1', borderRadius: 14, border: '1px solid #2a2a4a', touchAction: 'none',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 34,
                  background: playing && active === i ? (activeType === 'g' ? '#b8860b' : activeType === 'b' ? '#7a1f1f' : '#6c5cff') : '#12121a', overflow: 'visible' }}>
                {playing && active === i && <span style={{ animation: 'bbIn .12s ease-out' }}>{activeType === 'g' ? '🌟' : activeType === 'b' ? '💣' : '📦'}</span>}
                {boom && boom.cell === i && (
                  <>
                    <span key={'b' + boom.id} style={{ position: 'absolute', fontSize: 40, animation: 'bbPop .35s ease-out forwards', pointerEvents: 'none' }}>💥</span>
                    <span key={'p' + boom.id} style={{ position: 'absolute', fontSize: 18, fontWeight: 'bold', color: '#ffd84d', animation: 'bbRise .6s ease-out forwards', pointerEvents: 'none' }}>{boom.pts > 0 ? '+' : ''}{boom.pts}</span>
                  </>
                )}
              </div>
            ))}
          </div>
          <button onClick={startGame} disabled={playing} style={btn(playing)}>
            {playing ? 'বক্সে ট্যাপ করুন!' : lastScore || score ? '▶️ আবার খেলুন' : '▶️ খেলা শুরু করুন'}
          </button>
          <p style={{ fontSize: 11, color: '#aaa', textAlign: 'center', margin: '8px 0 0' }}>
            {GAME_SECONDS} সেকেন্ডে বক্স যে ঘরে আসে সেখানে ট্যাপ করে ফাটান। 📦 র‍্যান্ডম পয়েন্ট, 🌟 গোল্ডেন +১৫, 💣 বোমা −১০। টানা ৫টা ফাটালে কম্বো গুণক বাড়ে। পয়েন্ট = কয়েন। বিজ্ঞাপন সম্পূর্ণ ঐচ্ছিক।
          </p>
        </div>

        {!playing && canExtra && (
          <div style={card}>
            <div style={{ marginBottom: 8 }}>⏱ আরও {EXTRA_SECONDS} সেকেন্ড খেলতে চান? (ঐচ্ছিক বিজ্ঞাপন)</div>
            <button onClick={claimExtra} disabled={busy} style={btn(busy)}>{busy ? '⏳ লোড হচ্ছে...' : `▶️ বিজ্ঞাপন দেখে +${EXTRA_SECONDS} সেকেন্ড`}</button>
          </div>
        )}

        {!playing && !bonusDone && lastScore > 0 && (
          <div style={card}>
            <div style={{ marginBottom: 8 }}>🎉 আপনি পেয়েছেন {lastScore} কয়েন। চাইলে বিজ্ঞাপন দেখে আরও +{lastScore} নিন (ঐচ্ছিক)।</div>
            <button onClick={claimDouble} disabled={busy} style={btn(busy, false)}>{busy ? '⏳ লোড হচ্ছে...' : `▶️ বিজ্ঞাপন দেখে +${lastScore}`}</button>
          </div>
        )}

        <div style={card}>
          <div style={{ fontWeight: 'bold', marginBottom: 8 }}>🎯 আজকের মিশন</div>
          <div style={{ fontSize: 13, color: m.c1 ? '#4ade80' : '#ddd' }}>{m.c1 ? '✅' : '⬜'} ৫০টা বক্স ফাটান ({Math.min(m.blast, 50)}/50) +30</div>
          <div style={{ fontSize: 13, marginTop: 4, color: m.c2 ? '#4ade80' : '#ddd' }}>{m.c2 ? '✅' : '⬜'} এক গেমে ১০০ স্কোর করুন +30</div>
        </div>

        <div style={{ ...card, background: 'linear-gradient(135deg,#6c5cff,#00d2ff)', textAlign: 'center' }}>
          <div style={{ fontWeight: 'bold', fontSize: 17 }}>🔥 Daily Streak: {streak} দিন</div>
          <button onClick={claimDaily} disabled={dailyClaimed || busy || playing} style={{ ...btn(dailyClaimed || busy || playing, false), marginTop: 10 }}>
            {dailyClaimed ? '✅ আজকের বোনাস নেওয়া হয়েছে' : '▶️ ডেইলি বোনাস +50 (ঐচ্ছিক বিজ্ঞাপন)'}
          </button>
        </div>

        <p style={{ fontSize: 11, color: '#777', textAlign: 'center', marginTop: 16, lineHeight: 1.5 }}>
          কয়েন শুধুমাত্র অ্যাপের ভেতরের স্কোরের জন্য; এর কোনো নগদ মূল্য নেই এবং তোলা যায় না।
        </p>
      </div>
    </div>
  );
}
