# BoxBlast (Telegram Mini App)
1. `npm install`
2. `.env.local` এ `VITE_ADSGRAM_BLOCK_ID` দিন (Reward ব্লকের numeric ID)
3. `npm run build` → `dist/` হোস্ট করুন (HTTPS), BotFather এ Mini App হিসেবে যুক্ত করুন
