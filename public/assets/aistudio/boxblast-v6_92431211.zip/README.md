# BoxBlast (Telegram Mini App)
Env (Vercel → Settings → Environment Variables):
- VITE_ADSGRAM_BLOCK_ID = Adsgram REWARD ব্লকের numeric ID (int- ছাড়া)
- VITE_BOT_LINK = https://t.me/YourBot/shortname

npm install → npm run build → dist/ (Vercel: Framework Vite, Output dist)
