import { useState, useEffect, useRef, type CSSProperties } from 'react';

declare global { interface Window { Adsgram: any; Telegram: any; } }

const ENV = (import.meta as any).env || {};
const BLOCK_ID: string = ENV.VITE_ADSGRAM_BLOCK_ID || ''; // Adsgram REWARD ব্লকের numeric ID
const BOT_LINK: string = ENV.VITE_BOT_LINK || '';          // যেমন https://t.me/YourBot/play
const MAX_ADS = 8, BLOCK_SIZE = 10, SKIP_FEE = 5, TRIES = 3, GOLD = 15, HINT = 0.4;
const RADAR_COST = 10, RADAR_MOVES = 6, TRY_COST = 8, MAX_TRIES = 5;
const STREAK_REWARDS = [20, 30, 40, 50, 70, 90, 150];
const TITLES = ['Rookie', 'Scout', 'Hunter', 'Expert', 'Master', 'Legend'];
const MISSIONS = [
  { k: 'blast', n: 30, r: 30, t: '৩০টা বক্স ফাটান' },
  { k: 'perfect', n: 10, r: 40, t: '১০ বার প্রথম চেষ্টায় ফাটান' },
  { k: 'blocks', n: 2, r: 50, t: '২ রাউন্ড (২০ বক্স) শেষ করুন' },
] as const;

const today = () => new Date().toISOString().split('T')[0];
const yesterday = () => new Date(Date.now() - 86400000).toISOString().split('T')[0];
const level = (xp: number) => 1 + Math.floor(xp / 300);
const title = (xp: number) => TITLES[Math.min(5, Math.floor((level(xp) - 1) / 3))];
const haptic = (k: 'light' | 'medium' = 'light') => { try { window.Telegram?.WebApp?.HapticFeedback?.impactOccurred(k); } catch { /* */ } };

type S = { coins: number; xp: number; streak: number; lastDaily: string; blasts: number; perfect: number; seen: boolean;
  adsDate: string; adsN: number; md: string; m: { blast: number; perfect: number; blocks: number }; mc: boolean[] };
const INIT: S = { coins: 50, xp: 0, streak: 0, lastDaily: '', blasts: 0, perfect: 0, seen: false, adsDate: '', adsN: 0, md: '', m: { blast: 0, perfect: 0, blocks: 0 }, mc: [false, false, false] };
function load(): S {
  let s: S = { ...INIT };
  try { s = { ...INIT, ...JSON.parse(localStorage.getItem('bb2') || '{}') }; } catch { /* */ }
  if (s.md !== today()) { s.md = today(); s.m = { blast: 0, perfect: 0, blocks: 0 }; s.mc = [false, false, false]; }
  if (s.adsDate !== today()) { s.adsDate = today(); s.adsN = 0; }
  if (s.lastDaily && s.lastDaily !== today() && s.lastDaily !== yesterday()) s.streak = 0;
  return s;
}

export default function App() {
  const [s, setS] = useState<S>(load);
  const sRef = useRef(s); sRef.current = s;
  const upd = (f: (p: S) => S) => setS((p) => { const n = f(p); try { localStorage.setItem('bb2', JSON.stringify(n)); } catch { /* */ } return n; });
  const addCoins = (n: number) => upd((p) => ({ ...p, coins: Math.max(0, p.coins + n) }));

  const [tab, setTab] = useState<'play' | 'tasks' | 'me'>('play');
  const [msg, setMsg] = useState('');
  const [busy, setBusy] = useState(false);
  const [phase, setPhase] = useState<'idle' | 'play' | 'gate'>('idle');
  const [blasted, setBlasted] = useState(0);
  const [tries, setTries] = useState(TRIES);
  const [radar, setRadar] = useState(0);
  const [glim, setGlim] = useState<{ cell: number; id: number } | null>(null);
  const [shake, setShake] = useState<{ cell: number; id: number } | null>(null);
  const [boom, setBoom] = useState<{ cell: number; pts: number; gold: boolean; perfect: boolean; id: number } | null>(null);
  const [pendingDouble, setPendingDouble] = useState(0);

  const adRef = useRef<any>(null);
  const phaseRef = useRef<'idle' | 'play' | 'gate'>('idle');
  const boxRef = useRef(0), triesRef = useRef(TRIES), blockRef = useRef(0), radarRef = useRef(0);
  const moveT = useRef<any>(null), lastTap = useRef(0);

  const flash = (t: string, ms = 2200) => { setMsg(t); setTimeout(() => setMsg(''), ms); };
  const setPh = (p: 'idle' | 'play' | 'gate') => { phaseRef.current = p; setPhase(p); };
  const tgUser = window.Telegram?.WebApp?.initDataUnsafe?.user;

  useEffect(() => {
    try {
      const tg = window.Telegram?.WebApp;
      if (tg?.initData) { tg.ready(); tg.expand(); tg.disableVerticalSwipes?.(); tg.setHeaderColor?.('#1c1c2e'); tg.setBackgroundColor?.('#0e0e1a'); }
      if (window.Adsgram && BLOCK_ID) adRef.current = window.Adsgram.init({ blockId: BLOCK_ID });
    } catch { /* */ }
    return () => clearTimeout(moveT.current);
  }, []);

  // লুকানো বক্স এলোমেলো ঘর বদলায়; ✨ ঝিলিক ৪০% সত্যি ইঙ্গিত (রাডার থাকলে ১০০% সত্যি)
  const scheduleMove = () => {
    clearTimeout(moveT.current);
    moveT.current = setTimeout(() => {
      if (phaseRef.current !== 'play') return;
      let c = Math.floor(Math.random() * 9);
      if (c === boxRef.current) c = (c + 1 + Math.floor(Math.random() * 8)) % 9;
      boxRef.current = c;
      const real = radarRef.current > 0 || Math.random() < HINT;
      if (radarRef.current > 0) { radarRef.current -= 1; setRadar(radarRef.current); }
      setGlim({ cell: real ? c : Math.floor(Math.random() * 9), id: Date.now() });
      scheduleMove();
    }, Math.max(550, 850 - blockRef.current * 25));
  };
  const newBox = () => { boxRef.current = Math.floor(Math.random() * 9); triesRef.current = TRIES; setTries(TRIES); scheduleMove(); };
  const startBlock = () => { blockRef.current = 0; setBlasted(0); setBoom(null); setPh('play'); newBox(); };

  const tapCell = (i: number) => {
    if (phaseRef.current !== 'play') return;
    const now = Date.now();
    if (now - lastTap.current < 120) return;
    lastTap.current = now;
    if (i === boxRef.current) {
      const perfect = triesRef.current === TRIES, gold = Math.random() < 0.12;
      const pts = (gold ? GOLD : 1 + Math.floor(Math.random() * 9)) + (perfect ? 2 : 0);
      const before = level(sRef.current.xp);
      setBoom({ cell: i, pts, gold, perfect, id: now }); haptic('medium');
      upd((p) => ({ ...p, coins: p.coins + pts, xp: p.xp + pts, blasts: p.blasts + 1, perfect: p.perfect + (perfect ? 1 : 0),
        m: { ...p.m, blast: p.m.blast + 1, perfect: p.m.perfect + (perfect ? 1 : 0) } }));
      if (level(sRef.current.xp + pts) > before) flash(`🎉 লেভেল আপ! Lv ${before + 1}`);
      blockRef.current += 1; setBlasted(blockRef.current);
      if (blockRef.current >= BLOCK_SIZE) { clearTimeout(moveT.current); upd((p) => ({ ...p, m: { ...p.m, blocks: p.m.blocks + 1 } })); setPh('gate'); }
      else newBox();
    } else {
      triesRef.current -= 1; setTries(triesRef.current); setShake({ cell: i, id: now }); haptic('light');
      if (triesRef.current <= 0) { flash('📦 বক্স পালিয়ে গেছে! নতুন বক্স আসছে', 1600); newBox(); }
    }
  };

  const showAd = async (): Promise<boolean> => {
    if (sRef.current.adsN >= MAX_ADS) { flash('আজকের বিজ্ঞাপন সীমা শেষ।'); return false; }
    if (!window.Telegram?.WebApp?.initData || !adRef.current) { flash('বিজ্ঞাপন দেখতে অ্যাপটি Telegram এর ভেতরে খুলুন।'); return false; }
    setBusy(true);
    try { await adRef.current.show(); upd((p) => ({ ...p, adsN: p.adsN + 1 })); return true; }
    catch (e: any) { flash(/no.?ad/i.test(String(e?.description)) ? 'এখন কোনো বিজ্ঞাপন নেই, পরে চেষ্টা করুন।' : 'বিজ্ঞাপন শেষ পর্যন্ত দেখা হয়নি।'); return false; }
    finally { setBusy(false); }
  };

  const gateAd = async () => { if (await showAd()) startBlock(); };
  const gatePay = () => { const fee = Math.min(SKIP_FEE, s.coins); addCoins(-fee); flash(fee ? `−${fee} কয়েন` : 'চালিয়ে যান!', 1400); startBlock(); };
  const buyRadar = () => { if (s.coins < RADAR_COST) return flash('কয়েন কম'); addCoins(-RADAR_COST); radarRef.current = RADAR_MOVES; setRadar(RADAR_MOVES); };
  const freeRadar = async () => { if (await showAd()) { radarRef.current = RADAR_MOVES; setRadar(RADAR_MOVES); } };
  const buyTry = () => { if (s.coins < TRY_COST) return flash('কয়েন কম'); if (triesRef.current >= MAX_TRIES) return; addCoins(-TRY_COST); triesRef.current += 1; setTries(triesRef.current); };

  const claimedToday = s.lastDaily === today();
  const filled = claimedToday ? ((s.streak - 1) % 7) + 1 : s.streak % 7;
  const claimDaily = () => {
    if (claimedToday) return;
    const r = STREAK_REWARDS[s.streak % 7];
    upd((p) => ({ ...p, coins: p.coins + r, xp: p.xp + r, streak: p.streak + 1, lastDaily: today() }));
    setPendingDouble(r); flash(`✅ ডেইলি রিওয়ার্ড +${r}`);
  };
  const doubleDaily = async () => { if (pendingDouble && (await showAd())) { addCoins(pendingDouble); flash(`✅ বোনাস +${pendingDouble}`); setPendingDouble(0); } };
  const claimMission = (i: number) => {
    const ms = MISSIONS[i];
    if (sRef.current.m[ms.k] < ms.n || sRef.current.mc[i]) return;
    upd((p) => ({ ...p, coins: p.coins + ms.r, xp: p.xp + ms.r, mc: p.mc.map((v, j) => (j === i ? true : v)) })); flash(`🎯 +${ms.r}`);
  };
  const share = () => {
    if (!BOT_LINK) return flash('বট লিংক সেট করা নেই');
    const url = `https://t.me/share/url?url=${encodeURIComponent(BOT_LINK)}&text=${encodeURIComponent('📦 BoxBlast খেলো! লুকানো বক্স খুঁজে ফাটাও 🎯')}`;
    const tg = window.Telegram?.WebApp; if (tg?.openTelegramLink) tg.openTelegramLink(url); else window.open(url, '_blank');
  };

  const playing = phase === 'play';
  const card: CSSProperties = { background: '#1c1c2e', borderRadius: 16, padding: 14, marginTop: 12 };
  const btn = (off: boolean, kind: 'p' | 'w' | 'g' = 'p'): CSSProperties => ({ width: '100%', padding: 12, borderRadius: 10, border: 0, fontWeight: 'bold', fontSize: 14, touchAction: 'manipulation',
    background: off ? '#333' : kind === 'p' ? '#6c5cff' : kind === 'w' ? '#fff' : '#222', color: off ? '#777' : kind === 'p' ? '#fff' : kind === 'w' ? '#000' : '#aaa', cursor: off ? 'not-allowed' : 'pointer' });
  const small = (off: boolean): CSSProperties => ({ ...btn(off), padding: 9, fontSize: 12, flex: 1 });
  const xpPct = ((s.xp % 300) / 300) * 100;
  const adsLeft = MAX_ADS - s.adsN;

  return (
    <div style={{ background: '#0e0e1a', color: '#fff', fontFamily: 'system-ui,sans-serif', minHeight: '100vh', userSelect: 'none', WebkitUserSelect: 'none', WebkitTapHighlightColor: 'transparent', paddingBottom: 90 }}>
      <style>{`
        @keyframes bbPop{0%{transform:scale(.4);opacity:1}60%{transform:scale(1.5);opacity:1}100%{transform:scale(1.9);opacity:0}}
        @keyframes bbRise{0%{transform:translateY(0);opacity:1}100%{transform:translateY(-34px);opacity:0}}
        @keyframes bbGlim{0%{opacity:.6}100%{opacity:0}}
        @keyframes bbShake{0%,100%{transform:translateX(0)}25%{transform:translateX(-5px)}75%{transform:translateX(5px)}}
      `}</style>

      <div style={{ padding: '12px 16px', background: '#1c1c2e', position: 'sticky', top: 0, zIndex: 5 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div><b>📦 BoxBlast</b><div style={{ fontSize: 11, color: '#9a9ad0' }}>{tgUser?.first_name || 'Player'} · {title(s.xp)} · Lv {level(s.xp)}</div></div>
          <span style={{ background: '#6c5cff', padding: '5px 14px', borderRadius: 20, fontWeight: 'bold' }}>⭐ {s.coins}</span>
        </div>
        <div style={{ height: 5, background: '#12121a', borderRadius: 3, marginTop: 8 }}><div style={{ width: xpPct + '%', height: '100%', background: '#00d2ff', borderRadius: 3 }} /></div>
      </div>
      {msg && <div style={{ margin: '8px 14px', padding: 10, borderRadius: 10, textAlign: 'center', background: '#6c5cff', position: 'sticky', top: 62, zIndex: 6 }}>{msg}</div>}

      <div style={{ padding: '4px 14px' }}>
        {tab === 'play' && (<>
          <div style={card}>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 14 }}>
              <span>📦 <b>{blasted}/{BLOCK_SIZE}</b></span>
              <span>{radar > 0 ? `📡 ${radar} ` : ''}{playing ? '🎯 ' + '●'.repeat(tries) + '○'.repeat(Math.max(0, TRIES - tries)) : ''}</span>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 10, margin: '14px 0' }}>
              {Array.from({ length: 9 }, (_, i) => i).map((i) => (
                <div key={'c' + i + (shake && shake.cell === i ? shake.id : '')} onPointerDown={(e) => { e.preventDefault(); tapCell(i); }}
                  style={{ position: 'relative', aspectRatio: '1', borderRadius: 14, border: '1px solid #2a2a4a', touchAction: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#12121a',
                    animation: shake && shake.cell === i ? 'bbShake .25s' : undefined }}>
                  {playing && glim && glim.cell === i && <span key={'g' + glim.id} style={{ position: 'absolute', fontSize: 26, animation: 'bbGlim .5s ease-out forwards', pointerEvents: 'none' }}>✨</span>}
                  {boom && boom.cell === i && (<>
                    <span key={'b' + boom.id} style={{ position: 'absolute', fontSize: 40, animation: 'bbPop .35s ease-out forwards', pointerEvents: 'none' }}>💥</span>
                    <span key={'p' + boom.id} style={{ position: 'absolute', fontSize: 17, fontWeight: 'bold', color: boom.gold ? '#ffd84d' : '#fff', animation: 'bbRise .7s ease-out forwards', pointerEvents: 'none' }}>{boom.gold ? '🌟' : ''}+{boom.pts}{boom.perfect ? '⚡' : ''}</span>
                  </>)}
                </div>
              ))}
            </div>
            {phase === 'idle' && <button onClick={startBlock} style={btn(false)}>▶️ খেলা শুরু করুন</button>}
            <p style={{ fontSize: 11, color: '#aaa', textAlign: 'center', margin: '8px 0 0', lineHeight: 1.5 }}>
              {playing ? 'বক্স লুকিয়ে ঘর বদলাচ্ছে। ✨ ঝিলিক দেখে অনুমান করে ট্যাপ করুন (ঝিলিক সবসময় সত্যি নয়)। প্রথম চেষ্টায় ফাটালে ⚡ +২ বোনাস।' : 'প্রতি বক্সে ৩টা সুযোগ। ঠিক ঘরে ট্যাপ করলে বক্স ফেটে র‍্যান্ডম পয়েন্ট (১–৯, 🌟 গোল্ডেন +১৫) পাবেন।'}
            </p>
          </div>

          <div style={card}>
            <div style={{ fontWeight: 'bold', marginBottom: 8 }}>🛠 বুস্টার</div>
            <div style={{ display: 'flex', gap: 8 }}>
              <button style={small(!playing || s.coins < RADAR_COST || radar > 0)} disabled={!playing || s.coins < RADAR_COST || radar > 0} onClick={buyRadar}>📡 রাডার ⭐{RADAR_COST}</button>
              <button style={small(!playing || s.coins < TRY_COST || tries >= MAX_TRIES)} disabled={!playing || s.coins < TRY_COST || tries >= MAX_TRIES} onClick={buyTry}>➕ সুযোগ ⭐{TRY_COST}</button>
            </div>
            <button style={{ ...btn(!playing || busy || adsLeft <= 0 || radar > 0, 'w'), marginTop: 8, fontSize: 12 }} disabled={!playing || busy || adsLeft <= 0 || radar > 0} onClick={freeRadar}>▶️ বিজ্ঞাপন দেখে ফ্রি রাডার (ঐচ্ছিক)</button>
            <div style={{ fontSize: 11, color: '#888', marginTop: 6 }}>রাডার {RADAR_MOVES} চালের জন্য ✨ ঝিলিক সবসময় সঠিক ঘর দেখায়।</div>
          </div>

          {phase === 'gate' && (
            <div style={{ ...card, border: '2px solid #6c5cff' }}>
              <div style={{ fontWeight: 'bold', marginBottom: 4 }}>🎉 {BLOCK_SIZE}টা বক্স ফাটালেন!</div>
              <div style={{ fontSize: 13, color: '#ccc', marginBottom: 10 }}>চালিয়ে যেতে একটা বেছে নিন:</div>
              <button onClick={gateAd} disabled={busy || adsLeft <= 0} style={btn(busy || adsLeft <= 0, 'w')}>{busy ? '⏳ লোড হচ্ছে...' : '▶️ বিজ্ঞাপন দেখে বিনামূল্যে চালান'}</button>
              <button onClick={gatePay} disabled={busy} style={{ ...btn(busy), marginTop: 8 }}>⭐ {Math.min(SKIP_FEE, s.coins)} কয়েন দিয়ে চালান (বিজ্ঞাপন ছাড়া)</button>
              <button onClick={() => setPh('idle')} disabled={busy} style={{ ...btn(busy, 'g'), marginTop: 8 }}>এখানেই থামুন</button>
            </div>
          )}
        </>)}

        {tab === 'tasks' && (<>
          <div style={{ ...card, background: 'linear-gradient(135deg,#6c5cff,#00d2ff)' }}>
            <div style={{ fontWeight: 'bold', fontSize: 16, textAlign: 'center' }}>🔥 ডেইলি স্ট্রিক: {s.streak} দিন</div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7,1fr)', gap: 4, margin: '10px 0' }}>
              {STREAK_REWARDS.map((r, i) => (
                <div key={i} style={{ background: i < filled ? '#112a18' : '#0e0e1a99', borderRadius: 8, padding: '6px 0', textAlign: 'center', fontSize: 11, border: i === filled && !claimedToday ? '2px solid #fff' : '2px solid transparent' }}>
                  <div>{i < filled ? '✅' : 'D' + (i + 1)}</div><b>{r}</b>
                </div>))}
            </div>
            <button onClick={claimDaily} disabled={claimedToday} style={btn(claimedToday, 'w')}>{claimedToday ? '✅ আজকের রিওয়ার্ড নেওয়া হয়েছে' : `🎁 আজকের রিওয়ার্ড নিন (+${STREAK_REWARDS[s.streak % 7]})`}</button>
            {pendingDouble > 0 && <button onClick={doubleDaily} disabled={busy || adsLeft <= 0} style={{ ...btn(busy || adsLeft <= 0), marginTop: 8 }}>▶️ বিজ্ঞাপন দেখে আরও +{pendingDouble} (ঐচ্ছিক)</button>}
          </div>
          <div style={card}>
            <div style={{ fontWeight: 'bold', marginBottom: 8 }}>🎯 আজকের মিশন</div>
            {MISSIONS.map((ms, i) => {
              const v = Math.min(s.m[ms.k], ms.n), done = s.mc[i], ready = v >= ms.n && !done;
              return (
                <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '8px 0', borderTop: i ? '1px solid #2a2a4a' : 0 }}>
                  <div style={{ flex: 1, fontSize: 13, color: done ? '#4ade80' : '#ddd' }}>{done ? '✅' : '⬜'} {ms.t}<div style={{ fontSize: 11, color: '#888' }}>{v}/{ms.n} · +{ms.r} কয়েন</div></div>
                  <button onClick={() => claimMission(i)} disabled={!ready} style={{ ...btn(!ready), width: 80, padding: 8, fontSize: 12 }}>{done ? 'নেওয়া' : 'নিন'}</button>
                </div>);
            })}
          </div>
        </>)}

        {tab === 'me' && (<>
          <div style={{ ...card, textAlign: 'center' }}>
            <div style={{ fontSize: 40 }}>🧑‍🚀</div>
            <div style={{ fontWeight: 'bold', fontSize: 18 }}>{tgUser?.first_name || 'Player'}</div>
            <div style={{ color: '#9a9ad0', fontSize: 13 }}>{title(s.xp)} · Lv {level(s.xp)} · XP {s.xp}</div>
          </div>
          <div style={{ ...card, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, textAlign: 'center' }}>
            {[['📦 মোট ফাটানো', s.blasts], ['⚡ প্রথম চেষ্টায়', s.perfect], ['🔥 স্ট্রিক', s.streak], ['⭐ কয়েন', s.coins]].map(([l, v]) => (
              <div key={String(l)} style={{ background: '#12121a', borderRadius: 12, padding: 12 }}><div style={{ fontSize: 22, fontWeight: 'bold' }}>{v}</div><div style={{ fontSize: 11, color: '#888' }}>{l}</div></div>))}
          </div>
          <div style={card}><button onClick={share} style={btn(false)}>📨 বন্ধুদের ইনভাইট করুন</button></div>
          <p style={{ fontSize: 11, color: '#777', textAlign: 'center', marginTop: 16, lineHeight: 1.5 }}>কয়েন শুধুমাত্র অ্যাপের ভেতরের স্কোর ও বুস্টারের জন্য; এর কোনো নগদ মূল্য নেই এবং তোলা যায় না। বিজ্ঞাপন সম্পূর্ণ ঐচ্ছিক।</p>
        </>)}
      </div>

      <div style={{ position: 'fixed', bottom: 0, left: 0, right: 0, background: '#1c1c2e', display: 'flex', paddingBottom: 'env(safe-area-inset-bottom,0px)', borderTop: '1px solid #2a2a4a', zIndex: 8 }}>
        {([['play', '🎮', 'খেলা'], ['tasks', '🎯', 'টাস্ক'], ['me', '👤', 'প্রোফাইল']] as const).map(([k, ic, l]) => (
          <button key={k} onClick={() => setTab(k)} style={{ flex: 1, padding: '10px 0', border: 0, background: 'transparent', color: tab === k ? '#fff' : '#777', fontWeight: tab === k ? 'bold' : 'normal', fontSize: 12 }}>
            <div style={{ fontSize: 20 }}>{ic}</div>{l}{k === 'tasks' && (!claimedToday || s.mc.some((c, i) => !c && s.m[MISSIONS[i].k] >= MISSIONS[i].n)) ? ' 🔴' : ''}
          </button>))}
      </div>

      {!s.seen && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,.88)', zIndex: 50, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
          <div style={{ background: '#1c1c2e', borderRadius: 18, padding: 22, maxWidth: 340, border: '2px solid #6c5cff' }}>
            <h3 style={{ margin: '0 0 10px' }}>📦 BoxBlast এ স্বাগতম!</h3>
            <div style={{ fontSize: 14, lineHeight: 1.7, color: '#ddd' }}>১. লুকানো বক্স ঘর বদলাচ্ছে, অনুমান করে ট্যাপ করুন।<br />২. ✨ ঝিলিক ইঙ্গিত দেয় (সবসময় সত্যি নয়)।<br />৩. ঠিক ঘরে ট্যাপ করলে বক্স ফেটে কয়েন পাবেন।<br />৪. কয়েন দিয়ে বুস্টার নিন, মিশন ও ডেইলি রিওয়ার্ড সংগ্রহ করুন।<br />৫. বিজ্ঞাপন সম্পূর্ণ ঐচ্ছিক।</div>
            <button onClick={() => upd((p) => ({ ...p, seen: true }))} style={{ ...btn(false), marginTop: 14 }}>বুঝেছি, শুরু করি!</button>
          </div>
        </div>
      )}
    </div>
  );
}
